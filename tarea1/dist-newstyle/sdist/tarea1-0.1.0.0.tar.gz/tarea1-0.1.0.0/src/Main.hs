module Main where

main :: IO ()
esPalindromo :: String -> Bool
esPalindromo s = True
main = putStrLn "Tarea1 ejecutable claro que tambien"